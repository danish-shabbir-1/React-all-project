import mongoose from "mongoose";

mongoose.connect('mongodb+srv://Danish:Danish<1111>@cluster0.kpz22ga.mongodb.net/OlX-REPLICA')

export default mongoose