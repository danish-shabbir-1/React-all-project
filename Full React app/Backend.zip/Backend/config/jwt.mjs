const jwtSecret = 'abcdabcd'

export default jwtSecret